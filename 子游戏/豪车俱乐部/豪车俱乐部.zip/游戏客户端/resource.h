//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameClient.rc
//
#define IDR_MAINFRAME                   128
#define IDB_GAME_CARD                   149
#define IDB_BT_JETTON_10000             157
#define IDD_DLG_GAME_RECORD             177
#define IDB_GAME_END                    206
#define IDB_HAND                        237
#define IDC_ENABLE_SOUND                238
#define IDD_OPTION                      253
#define IDD_MESSAGEDLG                  254
#define IDD_DIALOG_MES                  264
#define IDB_LISTCTRL_BACK               319
#define IDB_SCROLL_BAR                  322
#define IDB_LIST_TITLE                  327
#define IDC_SCORE_1Y                    334
#define IDC_SCORE_5000W                 335
#define IDC_SCORE_1000W                 336
#define IDC_SCORE_500W                  337
#define IDC_SCORE_100W                  338
#define IDC_SCORE_50W                   339
#define IDC_SCORE_10W                   340
#define IDC_SCORE_1W                    341
#define IDC_SCORE_1000                  342
#define IDC_SCORE_100                   343
#define IDC_SCORE_5W                    344


#define IDD_BANKTIPS_DLG                357
#define IDB_SKIN_SCROLL                 362
#define IDB_USER_STATUS_IMAGE           363
#define IDR_MENU1                       364
#define IDC_CHECK_ALL                   1002

#define IDC_BUTTON_CLOSE                1018
#define IDC_ENABLE_BG_SOUND             1019
#define IDC_RADIO1                      1020
#define IDC_RADIO2                      1021
#define IDC_BUTTON1                     1022
#define IDC_RECORD_LIST                 1056
#define IDB_FLAG_PLAYER                 1060
#define IDB_FLAG_SYSTEM                 1061
#define IDB_IMAGE_TRUMPET               1064
#define IDB_IMAGE_TYPHON                1065
#define IDB_USER_LIST                   1066
#define IDC_GAME_GOLD                   6010
#define IDC_STORAGE_GOLD                6011
#define IDC_IN_COUNT                    6014
#define IDC_USER_PASSWORD               6015
#define IDD_BANK_STORAGE                8123
#define STATIC_PASS                     8129
#define IDC_STATIC_PASS                 8129
#define IDB_CENTREBACK                  8130
#define IDB_UNCHECK                     8131
#define IDB_CHECK                       8132
#define IDM_MORE_COLOR                  32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        365
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
