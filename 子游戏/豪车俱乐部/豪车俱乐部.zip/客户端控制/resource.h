//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClientControl.rc
//
#define IDC_RADIO_BEN_40                1000
#define IDC_RADIO_1                     1000
#define IDC_RADIO_BAO_30                1001
#define IDC_RADIO_2                     1001
#define IDC_RADIO_AO_20                 1002
#define IDC_RADIO_3                     1002
#define IDC_RADIO_DA_10                 1003
#define IDC_RADIO_4                     1003
#define IDC_COMBO_TIMES                 1004
#define IDC_RADIO_BEN_5                 1005
#define IDC_RADIO_5                     1005
#define IDC_RADIO_BAO_5                 1006
#define IDC_RADIO_6                     1006
#define IDC_RADIO_AO_5                  1007
#define IDC_RADIO_7                     1007
#define IDC_RADIO_DA_5                  1008
#define IDC_RADIO_8                     1008
#define IDC_BUTTON_RESET                1009
#define IDC_BUTTON_SYN                  1010
#define IDC_COMBO_TIMES_EX              1011
#define IDC_BUTTON_OK                   1011
#define IDC_STATIC_NOTIC_EX             1012
#define IDC_BUTTON_CANCEL               1012
#define IDC_STATIC_AREA_EX              1013
#define IDC_STATIC_TIMES                1013
#define IDC_STATIC_TIMES_EX             1014
#define IDC_STATIC_AREA                 1014
#define IDC_BUTTON_RESET_EX             1015
#define IDC_STATIC_NOTIC                1015
#define IDC_STATIC_TEXT_EX              1016
#define IDC_STATIC_TEXT                 1016
#define IDC_STATIC_INFO                 1017
#define IDC_BUTTON_SYN_EX               1019
#define IDC_BUTTON_OK_EX                1020
#define IDC_BUTTON_CANCEL_EX            1021
#define IDC_STATIC_INFO_EX              1022
#define IDC_CHECK_ZHUANG_EX             1023
#define IDC_CHECK_DONG_EX               1024
#define IDC_CHECK_NAN_EX                1025
#define IDC_CHECK_XI_EX                 1026
#define IDC_CHECK_BEI_EX                1027
#define IDC_BTN_UPDATE_STORAGE          3100
#define IDC_EDIT_STORAGE_START          3101
#define IDC_EDIT_STORAGE_DEDUCT         3102
#define IDC_EDIT_STORAGE_CURRENT        3103
#define IDC_EDIT_STORAGE_MAX1           3104
#define IDC_EDIT_STORAGE_MUL1           3105
#define IDC_EDIT_STORAGE_MAX2           3106
#define IDC_EDIT_STORAGE_MUL2           3107
#define IDC_LIST_USER_BET               3300
#define IDC_EDIT_USER_ID                3301
#define IDC_BTN_USER_BET_QUERY          3302
#define IDC_BTN_USER_BET_ALL            3303
#define IDC_LIST_USER_BET_ALL           3304
#define IDD_CLIENT_CONTROL_EX           6000
#define IDC_STATIC_EX                   6001
#define IDC_EDIT_KUCUN                  6002
#define IDC_BUTTON_ADDUSER              6003
#define IDC_RADIO_CT_BANKER             6004
#define IDC_RADIO_WIN                   6005
#define IDC_RADIO_LOSE                  6006
#define IDC_RADIO_CT_AREA               6007
#define IDC_STORAGE_STATIC              6008
#define IDC_COMBO_CHOOSE                6009
#define IDC_CHECK1                      6010
#define IDC_EDIT_ADDUSER                6011
#define IDC_STATIC_USERCOUNT            6012
#define IDC_STATIC_BETCOUNT             6013
#define IDC_BUTTON_DEL                  6014
#define IDC_LIST_ATTENTION_USER         6015
#define IDC_EDIT_CAR_1                  6016
#define IDC_EDIT_CAR_2                  6017
#define IDC_EDIT_CAR_3                  6018
#define IDC_EDIT_CAR_4                  6019
#define IDC_EDIT_CAR_5                  6020
#define IDC_EDIT_CAR_6                  6021
#define IDC_EDIT_CAR_7                  6022
#define IDC_EDIT_CAR_8                  6023
#define IDC_BUTTON_CAR_1                6024
#define IDC_BUTTON_CAR_2                6025
#define IDC_BUTTON_CAR_3                6026
#define IDC_BUTTON_CAR_4                6027
#define IDC_BUTTON_CAR_5                6028
#define IDC_BUTTON_CAR_6                6029
#define IDC_BUTTON_CAR_7                6030
#define IDC_BUTTON_CAR_8                6031
#define IDC_BTN_REFRESH_KUCUN           6032


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        6001
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6018
#define _APS_NEXT_SYMED_VALUE           6000
#endif
#endif
